"""
UI模块
包含插件配置页面和详情页面
"""
from .config import UIConfig

__all__ = ["UIConfig"]
